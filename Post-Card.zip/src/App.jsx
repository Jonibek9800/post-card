import PostList from "./components/PostList/PostList";

function App() {
  return <PostList />;
}

export default App;
